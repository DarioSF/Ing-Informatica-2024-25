import math
from casilla import Casilla

class Nodo:
    def __init__(self, casilla, padre=None, g=0, h=0):
        self.casilla = casilla  # Casilla actual (posición)
        self.padre = padre  # Nodo padre (de dónde venimos)
        self.g = g  # Costo desde el inicio hasta esta casilla
        self.h = h  # Heurística (estimación del costo desde esta casilla hasta la meta)
        self.f = g + h  # Costo total (g + h)

    def __lt__(self, other):
        return self.f < other.f  # Comparar nodos por f para obtener el mejor nodo

def reconstruir_camino(nodo_final):
    camino = []
    nodo_actual = nodo_final
    while nodo_actual is not None:
        camino.append((nodo_actual.casilla.getFila(), nodo_actual.casilla.getCol()))
        nodo_actual = nodo_actual.padre
    return camino[::-1]  # Invertir el camino para que vaya desde el origen hasta el destino


def a_estrella(mapi, origen, destino, calcular_heuristica, calcular_costo, camino):
    # Crear las listas de frontera (nodos a explorar) y lista interior (nodos ya explorados)
    lista_frontera = []
    lista_interior = set()

    # Nodo de inicio
    nodo_inicio = Nodo(origen, None, 0, calcular_heuristica(origen, destino))
    lista_frontera.append(nodo_inicio)

    while lista_frontera:
        # Obtener el nodo de la lista frontera con el menor valor de f
        lista_frontera.sort(key=lambda x: x.f)  # Ordenar por f
        nodo_actual = lista_frontera.pop(0)  # Nodo con menor f
        lista_interior.add((nodo_actual.casilla.getFila(), nodo_actual.casilla.getCol()))  # Añadir a explorados

        # Verificar si llegamos a la meta
        if nodo_actual.casilla.getFila() == destino.getFila() and nodo_actual.casilla.getCol() == destino.getCol():
            # Guardamos el coste antes de empezar a recorrer los padres
            coste_total = nodo_actual.g

            # Reconstruir el camino desde la meta al origen
            while nodo_actual is not None:
                fila_actual = nodo_actual.casilla.getFila()
                col_actual = nodo_actual.casilla.getCol()
                camino[fila_actual][col_actual] = 'x'  # Marcar solo el camino óptimo
                nodo_actual = nodo_actual.padre

            return coste_total  # Devolver solo el coste total

        # Explorar los vecinos
        vecinos = obtener_vecinos(nodo_actual.casilla, mapi)
        for vecino in vecinos:
            # Ignorar el vecino si ya está explorado
            if (vecino.getFila(), vecino.getCol()) in lista_interior:
                continue

            # Calcular los costos g, h y f para el vecino
            g_nuevo = nodo_actual.g + calcular_costo(nodo_actual.casilla, vecino)
            h_nuevo = calcular_heuristica(vecino, destino)
            f_nuevo = g_nuevo + h_nuevo

            # Comprobar si el vecino ya está en la lista frontera con un menor costo
            nodo_vecino = next((nodo for nodo in lista_frontera if nodo.casilla.getFila() == vecino.getFila() and nodo.casilla.getCol() == vecino.getCol()), None)
            if nodo_vecino is None:
                # Añadir el nuevo vecino a la lista frontera
                nuevo_nodo = Nodo(vecino, nodo_actual, g_nuevo, h_nuevo)
                lista_frontera.append(nuevo_nodo)
            elif g_nuevo < nodo_vecino.g:
                # Actualizar el nodo vecino con un nuevo mejor camino
                nodo_vecino.g = g_nuevo
                nodo_vecino.f = f_nuevo
                nodo_vecino.padre = nodo_actual

    return -1  # No se encontró un camino


def obtener_vecinos(casilla, mapi):
    vecinos = []
    movimientos = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]  # Ortogonales y diagonales
    for dx, dy in movimientos:
        nueva_fila = casilla.getFila() + dx
        nueva_col = casilla.getCol() + dy

        # Verificar que el vecino esté dentro del mapa y no sea una casilla bloqueada
        if 0 <= nueva_fila < mapi.getAlto() and 0 <= nueva_col < mapi.getAncho():
            if mapi.getCelda(nueva_fila, nueva_col) != 1:  # Suponiendo que 1 es una celda bloqueada
                vecinos.append(Casilla(nueva_fila, nueva_col))
    return vecinos


def calcular_costo(casilla_actual, vecino):
    # Si el movimiento es diagonal, el costo es 1.5, de lo contrario, 1
    dx = abs(casilla_actual.getFila() - vecino.getFila())
    dy = abs(casilla_actual.getCol() - vecino.getCol())
    if dx == 1 and dy == 1:
        return 1.5  # Movimiento diagonal
    return 1  # Movimiento ortogonal



def calcular_heuristica(casilla, destino, tipo="euclidiana"):
    dx = abs(casilla.getFila() - destino.getFila())
    dy = abs(casilla.getCol() - destino.getCol())
    
    if tipo == "manhattan":
        # Distancia de Manhattan
        return dx + dy
    elif tipo == "euclidiana":
        # Distancia Euclidiana
        return math.sqrt(dx ** 2 + dy ** 2)
    elif tipo == "chebyshev":
        # Distancia de Chebyshev
        return max(dx, dy)

# Ejemplo de llamada desde main.py:
# coste, camino = a_estrella(mapi, origen, destino, calcular_heuristica, calcular_costo)
